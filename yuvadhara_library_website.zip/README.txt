Yuvadhara Library Website
=========================
Open index.html in a browser to view the website.

Included:
- Responsive bilingual Malayalam/English design
- Home, About, Services, Activities, Membership, Gallery, Contact
- Uploaded library photographs
- Phone, WhatsApp and email links

To publish online, upload the entire folder contents to any static web host.
